import librosa
import numpy as np
import matplotlib.pyplot as plt
import librosa.display


onmei = ["A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#"]
count = 1

# for i in onmei:
# 	for j in range(25):
# 		try:
# 			# y, sr = librosa.read("off_" + i + count + ".wav")
# 			y, sr = librosa.load("./train_music/mute/mute_" + str(j) +".wav")
# 			fig = plt.figure()
# 			librosa.display.waveplot(y, sr = sr)
			
# 			fig.savefig("./train_pic/mute/mute_" + str(count) +".png")
# 			count += 1
# 		except Exception as e:
# 			print(e)

for j in range(25):
	try:
		# y, sr = librosa.read("off_" + i + count + ".wav")
		y, sr = librosa.load("./train_music/mute/mute_" + str(j) +".wav")
		fig = plt.figure()
		librosa.display.waveplot(y, sr = sr)
			
		fig.savefig("./train_pic/mute/mute_" + str(count) +".png")
		count += 1
	except Exception as e:
		print(e)
