import sys,os.path
import wave
import numpy as np

fileex = os.path.splitext("audio/2.webm")[1]
if fileex == (".webm"):
	print(fileex)