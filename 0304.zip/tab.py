def check_note(note, note_count):
	note_place = {1:["g,", "gis,", "a,", "ais,", "b,", "c", "cis", "d", "dis", "e", "f", "fis", "g", "gis", "a", "ais", "b", "c'", "cis'", "d'", "dis'", "e'", "f'"],
	2:["d,", "dis,", "e,", "f,", "fis,", "g,", "gis,", "a,", "ais,", "b,", "c", "cis", "d", "dis", "e", "f", "fis", "g", "gis", "a", "ais", "b", "c'"],
	3:["a,,", "ais,,", "b,,", "c,", "cis,", "d,", "dis,", "e,", "f,", "fis,", "g,", "gis,", "a,", "ais,", "b,", "c", "cis", "d", "dis", "e", "f", "fis", "g"],
	4:["e,,", "f,,", "fis,,", "g,,", "gis,,", "a,,", "ais,,", "b,,", "c,", "cis,", "d,", "dis,", "e,", "f,", "fis,", "g,", "gis,", "a,", "ais,", "b,", "c", "cis", "d"]}

	notes_dict = {"C1":[50, 50, 50, 0], "E2":[50, 50, 50, 0], "F2":[50, 50, 50, 1], "F#2":[50, 50, 50, 2], "G2":[50, 50, 50, 3], "G#2":[50, 50, 50, 4],
	"A2":[50, 50, 0, 5], "A#2":[50, 50, 1, 6], "B2":[50, 50, 2, 7], "C3":[50, 50, 3, 8],
	"C#3":[50, 50, 4, 9], "D3":[50, 0, 5, 10], "D#3":[50, 1, 6, 11], "E3":[50, 2, 7, 12],
	"F3":[50, 3, 8,13], "F#3":[50, 4, 9, 14], "G3":[0, 5, 10, 15],
	"G#3":[1, 6, 11, 16], "A3":[2, 7, 12, 17], "A#3":[3, 8, 13, 18],
	"B3":[4, 9, 14, 19], "C4":[5, 10, 15, 20], "C#4":[6, 11, 16, 21],
	"D4":[7, 12, 17, 22], "D#4":[8, 13, 18, 50], "E4":[9, 14, 19, 50],
	"F4":[10, 15, 20, 0], "F#4":[11, 16, 21, 0], "G4":[12, 17, 22, 50],
	"G#4":[13, 18, 50, 50], "A4":[14, 19, 50, 50], "A#4":[15, 20, 50, 50], "B4":[16, 21, 50, 50],
	"C5":[17, 22, 50, 50], "C#5":[18, 50, 50, 50], "D5":[19, 50, 50, 50], "D#5":[20, 50, 50, 50], "E5":[21, 50, 50, 50], "F5":[22, 50, 50, 50]}

	r_note = ""

	if note not in notes_dict:
		note = 'C1'

	if note_count == 0:
		for d in notes_dict:
			if note == d:
				notes_num = notes_dict[d].index(min(notes_dict[d]))
				r_note = note_place[notes_num + 1][notes_dict[d][min(notes_dict[d])]]
				return r_note, notes_num+1
	else:

		

def check_duration(array):


def check_play(array):


def check_tab(array):	
	text = check_note(array[0])

def tab(array, bpm):
	ly ="""
		\\new TabStaff \\with {
		stringTunings = #bass-tuning
	} {
		
		\\tempo 4=
	"""

	ly += bpm

	ly += """
	\\relative {

	"""


	for i in range(len(array)):
		if i == 0:
			